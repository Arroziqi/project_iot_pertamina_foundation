#include "IEM3155.h"
#include "PubFirebase.h"
#include <WiFiManager.h>

Adafruit_SSD1306 display(128, 64, &Wire, -1);
WiFiManager wm;

String DEVICE_ID = "Station1";

unsigned long timer, timer2;

void setup() {
  WiFi.mode(WIFI_STA);
  Serial.begin(115200);
  pinMode(D8, INPUT_PULLDOWN_16);
  // OLED setup

  mydisplayInit();
  modbusInit();

  Serial.print("WiFi Setup...");
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Please Connect SSID:");
  display.println("EMS-AccessPoint");
  display.setCursor(0, 30);
  display.println("Connecting To ...");
  display.println(WiFi.SSID());
  display.display();

  bool res;
  // res = wm.autoConnect(); // auto generated AP name from chipid
  // res = wm.autoConnect("AutoConnectAP"); // anonymous ap
  res = wm.autoConnect("EMS-AccessPoint","password"); // password protected ap

  if(!res) {
      Serial.println("Failed to connect");
      // ESP.restart();
  } 
  else {
      //if you get here you have connected to the WiFi    
      Serial.println("connected...yeey :)");
      display.clearDisplay();
      display.setCursor(0, 30);
      display.println("Connected!");
      display.print("IP:");
      display.println(WiFi.localIP());
      display.display();
      delay(1000);
  }

  firebaseInit();
  
  display.setCursor(0, 50);
  display.println("Setup Success");
  display.display();
  delay(1000);
} 

void loop() {
  int bounce = 0;
  while(digitalRead(D8)){
    display.clearDisplay();
    display.setTextSize(2);
    display.setCursor(0, 0);
    display.println("Press");
    display.println("3 Second");
    display.println("To Reset");
    display.display();
    bounce++;
    Serial.println(bounce);
    
    if(digitalRead(D8) and bounce>20){
      Serial.println("Restart");
      wm.resetSettings();
      delay(1000);
      ESP.reset();
    }
    delay(100);  
  }
  timeClient.update();
  unsigned long epoch = timeClient.getEpochTime();
  unsigned int connection_status = modbus_update(packets);
  if (millis() - timer >= 1000) {
    timer = millis();
    modbusData();
  }

  if(millis() - timer2 >= 5000){
    timer2 = millis();
    if (Firebase.ready()) {
      kirim_data(epoch);  // Convert epochTime to String here
    } 
    else {
      Serial.println("Firebase not ready. Check connection.");
    }
    Serial.println(timeClient.getEpochTime());
    Serial.println(timeClient.getFormattedTime());
  }
}

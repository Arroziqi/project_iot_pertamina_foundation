#include <FirebaseESP8266.h>
#include "displaysetup.h"

#include <NTPClient.h>
#include <WiFiUdp.h>

unsigned long timer3;

WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP,"pool.ntp.org", 0, 60000);

// Provide the token generation process info.
#include <addons/TokenHelper.h>
#include <addons/RTDBHelper.h>
#define API_KEY "AIzaSyDdQrkGN6prSgUhXkIcuzV91jkBY7ncf6Q"
#define DATABASE_URL "https://pertaminanre-c2d3e-default-rtdb.firebaseio.com"
#define USER_EMAIL "SmartEnergyStation@gmail.com"
#define USER_PASSWORD "PertaminaNREXUPer"

FirebaseData fbdo;
FirebaseAuth auth;
FirebaseConfig config;

unsigned long previousMillis = 0;
const long interval = 3000;  // Time interval in milliseconds
int currentState = 0; // State machine variable

void firebaseInit(){
  // WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  //   Serial.print("Connecting to Wi-Fi");
  //   display.clearDisplay();
  //   display.setTextColor(SSD1306_WHITE);
  //   display.setCursor(0, 0);
  //   display.println("Connecting to SSID:");
  //   display.println(WIFI_SSID);
  //   display.display();
  //   while (WiFi.status() != WL_CONNECTED)
  //   {
  //       Serial.print(".");
  //       display.print(".");
  //       display.display();
  //       delay(300);
  //   }
  //   Serial.println();
  //   Serial.print("Connected with IP: ");
  //   Serial.println(WiFi.localIP());
  //   Serial.println();

    Serial.printf("Firebase Client v%s\n\n", FIREBASE_CLIENT_VERSION);
    config.api_key = API_KEY;
    auth.user.email = USER_EMAIL;
    auth.user.password = USER_PASSWORD;
    config.database_url = DATABASE_URL;
    config.token_status_callback = tokenStatusCallback; // see addons/TokenHelper.h

    Firebase.begin(&config, &auth);
    // Firebase.reconnectWiFi(true);

    timeClient.begin();
}

void kirim_data(int epoch){ 
  // Display information on OLED
  show(meterData[35], "Energy", " kWh");
  // displayText("Energy: ", meterData[35], 0);
  // displayText("Voltage: ", meterData[13], 10);
  // displayText("Current: ", meterData[5], 20);
  // displayText("Power: ", meterData[17], 30);
  // displayText("Power Factor: ", meterData[29], 40);
  // displayText("Frequency: ", meterData[34], 50);

  unsigned long currentMillis = millis();

  switch (currentState) {
    case 0:
      show(meterData[35], "Energy", " kWh");
      break;
    case 1:
      show(meterData[13], "Voltage", "Volt");
      break;
    case 2:
      show(meterData[5], "Current", " Amp");
      break;
    case 3:
      show(meterData[17], "Power", "Watt");
      break;
    case 4:
      show(meterData[29], "CosPhi", "    ");
      break;
    case 5:
      show(meterData[34], "Frequency", "  Hz");
      break;
  }

  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;
    currentState++;

    if (currentState > 5) {
      currentState = 0; // Restart the sequence
    }
  }

  if(millis() - timer3 >= 900000){
    timer3 = millis();
    FirebaseJson json;
    json.setFloatDigits(2);
    json.add("Time PM", timeClient.getFormattedTime());
    json.add("CA", meterData[0]);
    json.add("CB", meterData[1]);
    json.add("CC", meterData[2]);
    json.add("CAVG", meterData[5]);

    json.add("VA", float(meterData[10]));
    json.add("VB", meterData[11]);
    json.add("VC", meterData[12]);
    json.add("VAVG", meterData[13]);

    json.add("WT", meterData[17]);
    json.add("VART", meterData[21]);
    json.add("VAT", meterData[25]);

    json.add("CosPhi", meterData[29]);
    json.add("Freq", meterData[34]);
    
    json.add("EI", meterData[35]);
    json.add("EE", meterData[36]);
    json.add("REI", meterData[37]);
    json.add("REE", meterData[38]);

    Serial.printf("Set json... %s\n", Firebase.RTDB.setJSON(&fbdo, ("station2/data/" + String(epoch)), &json) ? "ok" : fbdo.errorReason().c_str());
    Serial.println("DONE");
  }
  
}

